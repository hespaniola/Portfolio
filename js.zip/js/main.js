(function(){
  const html = document.documentElement;

  // Restore theme
  const saved = localStorage.getItem('theme');
  if (saved) {
    html.setAttribute('data-theme', saved);
  }

  // Theme toggle
  document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      html.setAttribute('data-theme', next);
      localStorage.setItem('theme', next);
    });
  });

  // Sticky header shadow (only if header exists)
  const header = document.querySelector('header.site-header');
  if (header) {
    const onScroll = () => {
      if (window.scrollY > 8) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    };
    window.addEventListener('scroll', onScroll);
    onScroll();
  }

  // Reveal-on-scroll
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.transition = 'opacity .35s ease, transform .35s ease';
        e.target.style.opacity = 1;
        e.target.style.transform = 'translateY(0)';
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('[data-reveal]').forEach(el => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(10px)';
    io.observe(el);
  });

  // Mobile menu toggle
  document.querySelectorAll('[data-menu-toggle]').forEach(t => {
    t.addEventListener('click', () => {
      const menu = document.querySelector('.mobile-menu');
      if (menu) menu.classList.toggle('open');
    });
  });

  // Active nav link
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('a[data-nav]').forEach(a => {
    const target = a.getAttribute('href');
    if (target && target.endsWith(path)) {
      a.classList.add('active');
    }
  });
})();
