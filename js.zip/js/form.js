(function(){
  const form = document.querySelector('form[data-contact]'); if(!form) return;
  const fields = {
    name: form.querySelector('#name'),
    email: form.querySelector('#email'),
    type: form.querySelector('#type'),
    message: form.querySelector('#message'),
    count: form.querySelector('#char-count')
  };
  const KEY = 'contact-draft-v1';
  function saveDraft(){
    const payload = { name:fields.name.value, email:fields.email.value, type:fields.type.value, message:fields.message.value };
    localStorage.setItem(KEY, JSON.stringify(payload));
  }
  function loadDraft(){
    try{
      const payload = JSON.parse(localStorage.getItem(KEY)||'null'); if(!payload) return;
      Object.entries(payload).forEach(([k,v])=>{ if(fields[k]) fields[k].value = v; });
      updateCount();
    }catch{}
  }
  function validate(){
    let ok=true; form.querySelectorAll('.input-error').forEach(e=>e.textContent='');
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.value);
    if(!fields.name.value.trim()){ form.querySelector('[data-err-name]').textContent='Please enter your name.'; ok=false; }
    if(!emailOk){ form.querySelector('[data-err-email]').textContent='Enter a valid email.'; ok=false; }
    if(!fields.message.value.trim()){ form.querySelector('[data-err-message]').textContent='Tell me a bit about your project.'; ok=false; }
    return ok;
  }
  function updateCount(){ const n = fields.message.value.length; fields.count && (fields.count.textContent = n); }
  ['input','change'].forEach(evt=> form.addEventListener(evt, e=>{ if(e.target===fields.message) updateCount(); saveDraft(); }));
  form.addEventListener('submit', e=>{
    e.preventDefault();
    if(!validate()) return;
    alert('Thanks! Your message was recorded (demo).');
    localStorage.removeItem(KEY);
    form.reset(); updateCount();
  });
  loadDraft(); updateCount();
})();