(function(){
  const backdrop = document.getElementById('lightbox-backdrop');
  const imgEl = document.getElementById('lightbox-img');
  const capEl = document.getElementById('lightbox-caption');
  function open(src, alt){
    imgEl.src = src; imgEl.alt = alt || '';
    capEl.textContent = alt || '';
    backdrop.classList.add('open'); imgEl.focus();
  }
  function close(){ backdrop.classList.remove('open'); imgEl.src=''; capEl.textContent=''; }
  backdrop?.addEventListener('click', (e)=>{ if(e.target===backdrop) close(); });
  document.addEventListener('keydown', (e)=>{ if(backdrop.classList.contains('open') && e.key==='Escape') close(); });
  document.querySelectorAll('[data-lightbox]').forEach(el=>{
    el.addEventListener('click', ()=> open(el.getAttribute('data-src') || el.src, el.getAttribute('alt') || el.getAttribute('data-alt') || ''));
  });
  window._lightbox = { open, close };
})();