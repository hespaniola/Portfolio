(async function () {
  const grid = document.querySelector('#projects-grid');
  const searchEl = document.querySelector('#search');
  const sortEl = document.querySelector('#sort');
  const filterButtons = document.querySelectorAll('[data-filter]');
  const loadMoreBtn = document.querySelector('#load-more');
  const modal = document.getElementById('project-modal');
  const modalBody = document.getElementById('project-modal-body');
  const modalClose = document.getElementById('project-modal-close');

  let data = []; let shown = 0; const PAGE = 6;
  const active = { type: 'all', q: '', sort: 'new' };

  try { const res = await fetch('assets/projects.json', { cache: 'no-store' }); data = await res.json(); }
  catch(e){ grid.innerHTML = '<p class="muted">Failed to load projects.</p>'; console.error(e); return; }

  function byFilters(p){
    const matchType = active.type === 'all' || p.type === active.type;
    const q = active.q.trim().toLowerCase();
    const hay = (p.title + ' ' + (p.summary||'') + ' ' + (p.tags||[]).join(' ')).toLowerCase();
    return matchType && (!q || hay.includes(q));
  }
  function sortData(arr){ return [...arr].sort((a,b)=> active.sort==='new' ? b.year - a.year : a.year - b.year); }
  function card(p){
    const tags = (p.tags||[]).map(t=>`<span class="badge">${t}</span>`).join(' ');
    return `<article class="card" data-reveal data-id="${p.id}" tabindex="0" role="button" aria-label="Open ${p.title}">
      <img src="${p.cover}" alt="${p.title} cover">
      <div class="card__body">
        <div class="row-center" style="justify-content:space-between">
          <h3 class="card__title">${p.title}</h3><small class="muted">${p.year}</small>
        </div>
        <p class="muted">${p.summary||''}</p>
        <div class="card__meta">${tags}</div>
      </div>
    </article>`;
  }
  function render(reset=false){
    const filtered = sortData(data.filter(byFilters));
    if(reset){ shown = 0; grid.innerHTML=''; }
    const next = filtered.slice(shown, shown+PAGE);
    grid.insertAdjacentHTML('beforeend', next.map(card).join(''));
    shown += next.length;
    loadMoreBtn.style.display = shown < filtered.length ? 'block' : 'none';
    grid.querySelectorAll('article.card').forEach(el => {
      el.addEventListener('click', ()=> openDetail(el.getAttribute('data-id')));
      el.addEventListener('keydown', e => { if(e.key==='Enter' || e.key===' ') { e.preventDefault(); openDetail(el.getAttribute('data-id')); } });
    });
  }
  function mediaHTML(p){
    const imgs = (p.media||[]).map(src=>`<img src="${src}" alt="${p.title}" style="border-radius:.5rem;">`).join('');
    const vid = p.video ? `<div class="card" style="overflow:hidden">
      <iframe width="100%" height="360" src="${p.video}" title="${p.title}" frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen></iframe></div>` : '';
    return vid + (imgs ? `<div class="grid cols-2" style="margin-top:1rem">${imgs}</div>` : '');
  }
  function openDetail(id){
    const p = data.find(x => x.id === id); if(!p) return;
    modalBody.innerHTML = `
      <h2 style="margin:0 0 .5rem">${p.title}</h2>
      <div class="muted" style="margin-bottom:.75rem">${p.year} • ${(p.tags||[]).join(' • ')}</div>
      <p>${p.details||p.summary||''}</p>
      <div class="divider"></div>
      ${mediaHTML(p)}
    `;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    modal.querySelector('.modal-panel').focus();
    document.body.style.overflow = 'hidden';
  }
  function closeDetail(){
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    modalBody.innerHTML = '';
  }
  filterButtons.forEach(btn=>btn.addEventListener('click', ()=>{
    active.type = btn.dataset.filter; render(true);
    filterButtons.forEach(b=>b.classList.toggle('active', b===btn));
  }));
  searchEl?.addEventListener('input', e=>{ active.q = e.target.value; render(true); });
  sortEl?.addEventListener('change', e=>{ active.sort = e.target.value; render(true); });
  loadMoreBtn?.addEventListener('click', ()=> render(false));

  modalClose?.addEventListener('click', closeDetail);
  modal?.addEventListener('click', e=>{ if(e.target===modal) closeDetail(); });
  document.addEventListener('keydown', e=>{ if(modal.classList.contains('open') && e.key==='Escape') closeDetail(); });

  render(true);
})();