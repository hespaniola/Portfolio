(function () {
  const canvas = document.getElementById("portfolioCanvas");
  if (!canvas) return; 
  const ctx = canvas.getContext("2d");
  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = Math.max(220, rect.width * 0.25);
  }
  resizeCanvas();
  window.addEventListener("resize", resizeCanvas);
  const ORB_COUNT = 26;
  const orbs = [];
  function randomBetween(min, max) {
    return Math.random() * (max - min) + min;
  }
  function createOrb() {
    return {
      x: randomBetween(0, canvas.width),
      y: randomBetween(0, canvas.height),
      radius: randomBetween(12, 32),
      vx: randomBetween(-0.35, 0.35),
      vy: randomBetween(-0.25, 0.25),
      hue: randomBetween(345, 10), // reds
      alpha: randomBetween(0.25, 0.6)
    };
  }
  function initOrbs() {
    orbs.length = 0;
    for (let i = 0; i < ORB_COUNT; i++) {
      orbs.push(createOrb());
    }
  }
  initOrbs();
  function update() {
    for (const orb of orbs) {
      orb.x += orb.vx;
      orb.y += orb.vy;

      // bounce at edges
      if (orb.x - orb.radius < 0 || orb.x + orb.radius > canvas.width) {
        orb.vx *= -1;
      }
      if (orb.y - orb.radius < 0 || orb.y + orb.radius > canvas.height) {
        orb.vy *= -1;
      }
    }
  }
  function draw() {
    // subtle dark overlay 
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, "rgba(15,23,42,0.95)");
    gradient.addColorStop(1, "rgba(15,23,42,0.8)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    for (const orb of orbs) {
      const g = ctx.createRadialGradient(
        orb.x, orb.y, orb.radius * 0.1,
        orb.x, orb.y, orb.radius
      );
      g.addColorStop(0, `hsla(${orb.hue}, 80%, 60%, ${orb.alpha + 0.25})`);
      g.addColorStop(1, `hsla(${orb.hue}, 80%, 40%, 0)`);

      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(orb.x, orb.y, orb.radius, 0, Math.PI * 2);
      ctx.fill();
    }
    // subtle grain / noise layer
    ctx.fillStyle = "rgba(255,255,255,0.03)";
    for (let i = 0; i < 80; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
  }

  loop();
})();
